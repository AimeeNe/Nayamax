import React, { useState, useEffect } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { Store, ShoppingBag, Globe2, Rocket, ArrowRight, CheckCircle2, Menu, X, Users, Shield, CreditCard, BarChart, Zap, Star, Plus, PlayCircle } from 'lucide-react';
import { Pricing } from './pages/Pricing';
import { SignUp } from './pages/SignUp';
import { Login } from './pages/Login';
import { Documentation } from './pages/Documentation';
import { About } from './pages/About';
import { Contact } from './pages/Contact';
import { Blog } from './pages/Blog';
import { BlogPost } from './pages/BlogPost';
import { Investors } from './pages/Investors';
import { Ecommerceconnect } from './pages/Ecommerceconnect';
import { VideoModal } from './components/VideoModal';

function App() {
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <Routes>
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/:slug" element={<BlogPost />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/documentation" element={<Documentation />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/investors" element={<Investors />} />
        <Route path="/ecommerceconnect" element={<Ecommerceconnect />} />
        <Route path="/" element={
          <div className="min-h-screen bg-white">
            {/* Navigation */}
            <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-lg' : 'bg-transparent'}`}>
              <div className="container mx-auto px-6 py-4">
                <div className="flex items-center justify-between">
                  <Link to="/" className="flex items-center space-x-2">
                    <img src="/nayamax-logo.png" alt="Nayamax" className="h-10" />
                  </Link>
                  
                  <div className="hidden md:flex space-x-8">
                    <a href="#features" className={`hover:text-nayamax-blue transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>Features</a>
                    <a href="#how-it-works" className={`hover:text-nayamax-blue transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>How It Works</a>
                    <Link to="/about" className={`hover:text-nayamax-blue transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>About</Link>
                    <Link to="/contact" className={`hover:text-nayamax-blue transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>Contact</Link>
                    <Link to="/pricing" className={`hover:text-nayamax-blue transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>Pricing</Link>
                  </div>
                  
                  <div className="hidden md:flex space-x-4">
                    <Link to="/login" className={`px-6 py-2 rounded-full font-semibold transition-colors ${isScrolled ? 'text-gray-700 hover:text-nayamax-blue' : 'text-white hover:text-blue-200'}`}>
                      Login
                    </Link>
                    <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-6 py-2 rounded-full font-semibold hover:bg-yellow-300 transition-colors">
                      Start Free
                    </Link>
                  </div>

                  <button 
                    className="md:hidden"
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                  >
                    {isMenuOpen ? 
                      <X className={isScrolled ? 'text-gray-900' : 'text-white'} /> : 
                      <Menu className={isScrolled ? 'text-gray-900' : 'text-white'} />
                    }
                  </button>
                </div>

                {isMenuOpen && (
                  <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-lg py-4">
                    <div className="flex flex-col space-y-4 px-6">
                      <a href="#features" className="text-gray-700 hover:text-nayamax-blue">Features</a>
                      <a href="#how-it-works" className="text-gray-700 hover:text-nayamax-blue">How It Works</a>
                      <Link to="/about" className="text-gray-700 hover:text-nayamax-blue">About</Link>
                      <Link to="/contact" className="text-gray-700 hover:text-nayamax-blue">Contact</Link>
                      <Link to="/pricing" className="text-gray-700 hover:text-nayamax-blue">Pricing</Link>
                      <hr className="border-gray-200" />
                      <Link to="/login" className="text-gray-700 hover:text-nayamax-blue text-left">Login</Link>
                      <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-6 py-2 rounded-full font-semibold hover:bg-yellow-300 transition-colors text-center">
                        Start Free
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </nav>

            {/* Hero Section */}
            <header className="relative bg-gradient-to-r from-nayamax-blue via-blue-800 to-nayamax-blue pt-24">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=2000&q=80')] opacity-10 bg-cover bg-center" />
              <div className="container mx-auto px-6 py-20 relative">
                <div className="flex flex-col md:flex-row items-center">
                  <div className="md:w-1/2 text-white">
                    <div className="inline-block px-4 py-2 bg-blue-800/50 rounded-full text-sm font-medium text-yellow-400 mb-6">
                      #1 E-commerce Platform in Burkina Faso
                    </div>
                    <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6">
                      Your Online Store, <br />
                      <span className="text-yellow-400">African</span> Made Simple
                    </h1>
                    <p className="text-xl text-blue-100 mb-8 leading-relaxed">
                      Launch your boutique in minutes with Nayamax - the most intuitive e-commerce platform designed specifically for African businesses.
                    </p>
                    <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                      <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors flex items-center justify-center">
                        Start Your Free Store <ArrowRight className="ml-2 h-5 w-5" />
                      </Link>
                      <button 
                        onClick={() => setIsVideoModalOpen(true)}
                        className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white/10 transition-colors flex items-center justify-center"
                      >
                        <PlayCircle className="mr-2 h-5 w-5" />
                        Watch Demo
                      </button>
                    </div>
                    <div className="mt-8 flex items-center space-x-6">
                      <div className="flex -space-x-2">
                        {[1, 2, 3, 4].map((i) => (
                          <img
                            key={i}
                            src={`https://images.unsplash.com/photo-${1500000000000 + i}?auto=format&fit=crop&w=100&h=100&q=80`}
                            alt={`User ${i}`}
                            className="w-10 h-10 rounded-full border-2 border-white object-cover"
                          />
                        ))}
                      </div>
                      <div className="text-sm">
                        <div className="font-semibold">Trusted by 2,000+ merchants</div>
                        <div className="text-blue-200">Across 10+ African countries</div>
                      </div>
                    </div>
                  </div>
                  <div className="md:w-1/2 mt-12 md:mt-0">
                    <div className="relative">
                      <div className="absolute -inset-4 bg-nayamax-blue/20 rounded-2xl blur-lg"></div>
                      <img 
                        src="https://images.unsplash.com/photo-1531973576160-7125cd663d86?auto=format&fit=crop&w=1200&q=80" 
                        alt="Nayamax Dashboard" 
                        className="relative rounded-2xl shadow-2xl border border-blue-700/20"
                      />
                      <div className="absolute -right-8 -bottom-8 bg-white p-4 rounded-lg shadow-xl">
                        <div className="flex items-center space-x-2">
                          <BarChart className="text-green-500 h-6 w-6" />
                          <div>
                            <div className="text-sm font-medium text-gray-900">Sales Today</div>
                            <div className="text-2xl font-bold text-gray-900">1.2M FCFA</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats Section */}
              <div className="container mx-auto px-6 pb-20">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  <StatCard 
                    number="2,000+"
                    label="Active Stores"
                    icon={<Store className="h-6 w-6 text-yellow-400" />}
                  />
                  <StatCard 
                    number="10+"
                    label="African Countries"
                    icon={<Globe2 className="h-6 w-6 text-yellow-400" />}
                  />
                  <StatCard 
                    number="500K+"
                    label="Orders Processed"
                    icon={<ShoppingBag className="h-6 w-6 text-yellow-400" />}
                  />
                  <StatCard 
                    number="99.9%"
                    label="Uptime"
                    icon={<Shield className="h-6 w-6 text-yellow-400" />}
                  />
                </div>
              </div>
            </header>

            {/* Features Section */}
            <section id="features" className="py-20 bg-gray-50">
              <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto mb-16">
                  <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                    Everything You Need to Succeed Online
                  </h2>
                  <p className="text-xl text-gray-600">
                    Built specifically for African businesses, Nayamax provides all the tools you need to create, manage, and grow your online store.
                  </p>
                </div>
                
                <div className="grid md:grid-cols-3 gap-8">
                  <FeatureCard 
                    icon={<Store className="h-8 w-8 text-nayamax-blue" />}
                    title="Quick Store Setup"
                    description="Launch your store in minutes with our intuitive dashboard and beautiful templates designed for African markets"
                    features={[
                      "Professional templates",
                      "Mobile-optimized stores",
                      "Custom domain support"
                    ]}
                  />
                  <FeatureCard 
                    icon={<CreditCard className="h-8 w-8 text-nayamax-blue" />}
                    title="Local Payment Methods"
                    description="Accept payments through popular African payment methods and mobile money services"
                    features={[
                      "Mobile Money integration",
                      "Bank transfers",
                      "Cash on delivery"
                    ]}
                  />
                  <FeatureCard 
                    icon={<BarChart className="h-8 w-8 text-nayamax-blue" />}
                    title="Business Analytics"
                    description="Make data-driven decisions with powerful analytics and reporting tools"
                    features={[
                      "Real-time sales tracking",
                      "Customer insights",
                      "Inventory management"
                    ]}
                  />
                </div>
              </div>
            </section>

            {/* How It Works Section */}
            <section id="how-it-works" className="py-20">
              <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto mb-16">
                  <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                    Start Selling in Three Simple Steps
                  </h2>
                  <p className="text-xl text-gray-600">
                    Get your online store up and running in minutes, not days
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-8 relative">
                  <div className="hidden md:block absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 w-2/3 h-0.5 bg-blue-100">
                    <div className="absolute top-1/2 left-0 w-full h-0.5 bg-nayamax-blue" style={{ width: '33%' }}></div>
                  </div>
                  
                  <StepCard 
                    number="1"
                    title="Create Account"
                    description="Sign up in seconds with just your basic information and business details"
                    image="https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?auto=format&fit=crop&w=800&q=80"
                  />
                  <StepCard 
                    number="2"
                    title="Customize Store"
                    description="Choose from our beautiful templates and add your products with our easy-to-use dashboard"
                    image="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80"
                  />
                  <StepCard 
                    number="3"
                    title="Start Selling"
                    description="Launch your store and start accepting orders immediately with local payment methods"
                    image="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=800&q=80"
                  />
                </div>
              </div>
            </section>

            {/* Testimonials Section */}
            <section id="testimonials" className="py-20 bg-nayamax-blue">
              <div className="container mx-auto px-6">
                <div className="text-center max-w-3xl mx-auto mb-16">
                  <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                    Trusted by African Businesses
                  </h2>
                  <p className="text-xl text-blue-100">
                    Join thousands of successful merchants who trust Nayamax
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                  <TestimonialCard 
                    quote="Nayamax transformed my small boutique into a thriving online business. The local payment integrations made it easy for my customers to shop."
                    author="Aminata Ouédraogo"
                    role="Fashion Boutique Owner"
                    image="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80"
                  />
                  <TestimonialCard 
                    quote="Setting up my store was incredibly easy. The support team understands the unique challenges we face in Africa and helps us overcome them."
                    author="Ibrahim Sankara"
                    role="Electronics Store Owner"
                    image="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80"
                  />
                  <TestimonialCard 
                    quote="The analytics tools helped me understand my customers better and grow my business. Nayamax is truly a game-changer for African commerce."
                    author="Marie Koné"
                    role="Beauty Products Retailer"
                    image="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=200&q=80"
                  />
                </div>
              </div>
            </section>

            {/* CTA Section */}
            <section className="relative py-20 overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-nayamax-blue to-blue-800"></div>
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?auto=format&fit=crop&w=2000&q=80')] opacity-10 bg-cover bg-center"></div>
              <div className="container mx-auto px-6 relative">
                <div className="max-w-3xl mx-auto text-center">
                  <h2 className="text-3xl md:text-4xl font-bold text-white mb-8">
                    Ready to Start Your Success Story?
                  </h2>
                  <p className="text-xl text-blue-100 mb-8">
                    Join thousands of successful African entrepreneurs who are growing their businesses with Nayamax
                  </p>
                  <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors inline-flex items-center">
                    Create Your Store Now <Rocket className="ml-2 h-5 w-5" />
                  </Link>
                  <p className="mt-6 text-blue-100">
                    No credit card required • 14-day free trial
                  </p>
                </div>
              </div>
            </section>

            {/* Footer */}
            <footer className="bg-gray-900 text-white py-12">
              <div className="container mx-auto px-6">
                <div className="grid md:grid-cols-4 gap-8">
                  <div>
                    <img src="/nayamax-logo.png" alt="Nayamax" className="h-8 mb-4" />
                    <p className="text-gray-400">
                      Making e-commerce accessible for everyone in Africa
                    </p>
                    <div className="mt-4 flex space-x-4">
                      <a href="#" className="text-gray-400 hover:text-white">
                        <span className="sr-only">Facebook</span>
                      </a>
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-4">Product</h3>
                    <ul className="space-y-2 text-gray-400">
                      <li><a href="#features" className="hover:text-white">Features</a></li>
                      <li><Link to="/pricing" className="hover:text-white">Pricing</Link></li>
                      <li><a href="#" className="hover:text-white">Templates</a></li>
                      <li><a href="#testimonials" className="hover:text-white">Success Stories</a></li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-4">Company</h3>
                    <ul className="space-y-2 text-gray-400">
                      <li><Link to="/about" className="hover:text-white">About</Link></li>
                      <li><Link to="/contact" className="hover:text-white">Contact</Link></li>
                      <li><Link to="/blog" className="hover:text-white">Blog</Link></li>
                      <li><Link to="/ecommerceconnect" className="hover:text-white">Ecommerceconnect</Link></li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-4">Support</h3>
                    <ul className="space-y-2 text-gray-400">
                      <li><a href="#" className="hover:text-white">Help Center</a></li>
                      <li><Link to="/documentation" className="hover:text-white">Documentation</Link></li>
                      <li><a href="#" className="hover:text-white">API</a></li>
                      <li><Link to="/investors" className="hover:text-white">Investors</Link></li>
                    </ul>
                  </div>
                </div>
                <div className="border-t border-gray-800 mt-12 pt-8">
                  <div className="flex flex-col md:flex-row justify-between items-center">
                    <p className="text-gray-400">
                      &copy; 2024 Nayamax. All rights reserved.
                    </p>
                    <div className="flex space-x-6 mt-4 md:mt-0">
                      <Link to="/privacy" className="text-gray-400 hover:text-white">Privacy Policy</Link>
                      <Link to="/terms" className="text-gray-400 hover:text-white">Terms of Service</Link>
                      <Link to="/cookies" className="text-gray-400 hover:text-white">Cookie Policy</Link>
                    </div>
                  </div>
                </div>
              </div>
            </footer>
          </div>
        } />
      </Routes>

      <VideoModal 
        isOpen={isVideoModalOpen}
        onClose={() => setIsVideoModalOpen(false)}
      />
    </>
  );
}

function FeatureCard({ icon, title, description, features }) {
  return (
    <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="inline-block p-3 bg-blue-50 rounded-lg mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600 mb-4">{description}</p>
      <ul className="space-y-2">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center text-gray-700">
            <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
            {feature}
          </li>
        ))}
      </ul>
    </div>
  );
}

function StepCard({ number, title, description, image }) {
  return (
    <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 relative z-10">
      <div className="absolute -top-4 -left-4 bg-nayamax-blue text-white w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold">
        {number}
      </div>
      <div className="mb-6 rounded-lg overflow-hidden">
        <img src={image} alt={title} className="w-full h-48 object-cover" />
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2 mt-4">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function TestimonialCard({ quote, author, role, image }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg p-8 rounded-xl">
      <div className="flex items-center mb-6">
        <img src={image} alt={author} className="w-12 h-12 rounded-full mr-4" />
        <div>
          <div className="font-semibold text-white">{author}</div>
          <div className="text-blue-200 text-sm">{role}</div>
        </div>
      </div>
      <p className="text-blue-100 italic">"{quote}"</p>
    </div>
  );
}

function StatCard({ number, label, icon }) {
  return (
    <div className="bg-white/10 backdrop-blur-lg p-6 rounded-xl">
      <div className="flex items-center space-x-4">
        <div className="p-2 bg-white/10 rounded-lg">
          {icon}
        </div>
        <div>
          <div className="text-2xl font-bold text-white">{number}</div>
          <div className="text-blue-200 text-sm">{label}</div>
        </div>
      </div>
    </div>
  );
}

export default App;