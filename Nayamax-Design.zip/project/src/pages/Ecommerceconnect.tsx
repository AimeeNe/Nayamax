import React from 'react';
import { Link } from 'react-router-dom';
import { Users, Globe2, MessageSquare, Share2, UserPlus, Building, ShoppingBag, ArrowRight } from 'lucide-react';
import { Navbar } from '../components/Navbar';

export function Ecommerceconnect() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-nayamax-blue to-blue-800 py-24">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?auto=format&fit=crop&w=2000&q=80')] opacity-10 bg-cover bg-center" />
        <div className="container mx-auto px-6 relative pt-20">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Connect with African E-commerce Leaders
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Join Africa's largest e-commerce community platform for networking, learning, and growth
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors">
                Join the Community
              </Link>
              <a href="#features" className="bg-white/10 text-white px-8 py-4 rounded-full font-semibold hover:bg-white/20 transition-colors">
                Learn More
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Users className="h-8 w-8 text-blue-600" />}
              title="Networking"
              description="Connect with fellow e-commerce entrepreneurs, share experiences, and build valuable relationships"
            />
            <FeatureCard
              icon={<MessageSquare className="h-8 w-8 text-blue-600" />}
              title="Knowledge Sharing"
              description="Access exclusive content, webinars, and discussions led by industry experts"
            />
            <FeatureCard
              icon={<Share2 className="h-8 w-8 text-blue-600" />}
              title="Collaboration"
              description="Find partners, suppliers, and opportunities for business growth"
            />
          </div>
        </div>
      </section>

      {/* Community Stats */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <StatCard
              icon={<UserPlus className="h-6 w-6 text-blue-600" />}
              number="5,000+"
              label="Community Members"
            />
            <StatCard
              icon={<Building className="h-6 w-6 text-blue-600" />}
              number="500+"
              label="Partner Companies"
            />
            <StatCard
              icon={<Globe2 className="h-6 w-6 text-blue-600" />}
              number="15+"
              label="Countries Represented"
            />
            <StatCard
              icon={<ShoppingBag className="h-6 w-6 text-blue-600" />}
              number="$50M+"
              label="Business Generated"
            />
          </div>
        </div>
      </section>

      {/* Events Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Upcoming Events</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <EventCard
              title="E-commerce Summit 2024"
              date="April 15-16, 2024"
              location="Dakar, Senegal"
              image="https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80"
            />
            <EventCard
              title="Digital Payment Forum"
              date="May 5, 2024"
              location="Virtual Event"
              image="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=800&q=80"
            />
            <EventCard
              title="Seller Workshop Series"
              date="Monthly"
              location="Multiple Locations"
              image="https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?auto=format&fit=crop&w=800&q=80"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-nayamax-blue">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Join Africa's Leading E-commerce Community
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Connect, learn, and grow with fellow entrepreneurs and industry experts
            </p>
            <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors inline-flex items-center">
              Get Started Now <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
      <div className="p-3 bg-blue-50 rounded-lg w-fit mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function StatCard({ icon, number, label }) {
  return (
    <div className="bg-gray-50 rounded-xl p-6 text-center">
      <div className="p-3 bg-white rounded-lg w-fit mx-auto mb-4">
        {icon}
      </div>
      <div className="text-2xl font-bold text-gray-900 mb-1">{number}</div>
      <div className="text-gray-600">{label}</div>
    </div>
  );
}

function EventCard({ title, date, location, image }) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300">
      <div className="h-48 relative">
        <img src={image} alt={title} className="w-full h-full object-cover" />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-gray-600 mb-1">{date}</p>
        <p className="text-gray-500">{location}</p>
        <button className="mt-4 text-blue-600 font-medium hover:text-blue-700">
          Learn More
        </button>
      </div>
    </div>
  );
}