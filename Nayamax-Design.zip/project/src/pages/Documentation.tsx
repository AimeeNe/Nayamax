import React from 'react';
import { Link } from 'react-router-dom';
import { Book, Code, Database, Shield, Zap, ArrowLeft, Search, ChevronRight } from 'lucide-react';

export function Documentation() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <img src="/nayamax-logo.png" alt="Nayamax" className="h-8" />
            </Link>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="search"
                  placeholder="Search documentation..."
                  className="pl-10 pr-4 py-2 w-64 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <Link
                to="/login"
                className="text-gray-700 hover:text-blue-600 font-medium"
              >
                Sign in
              </Link>
              <Link
                to="/signup"
                className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-12">
        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-8">
          <Link to="/" className="hover:text-blue-600">Home</Link>
          <ChevronRight className="h-4 w-4" />
          <span className="text-gray-900">Documentation</span>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-6">
              <nav className="space-y-1">
                <a href="#getting-started" className="block px-4 py-2 rounded-lg bg-blue-50 text-blue-700 font-medium">Getting Started</a>
                <a href="#api-reference" className="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50">API Reference</a>
                <a href="#authentication" className="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50">Authentication</a>
                <a href="#webhooks" className="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50">Webhooks</a>
                <a href="#sdks" className="block px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-50">SDKs & Libraries</a>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="prose max-w-none">
              <h1 className="text-4xl font-bold text-gray-900 mb-8">Documentation</h1>
              
              <div className="grid md:grid-cols-2 gap-6 mb-12">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                  <div className="p-3 bg-blue-50 rounded-lg w-fit mb-4">
                    <Zap className="h-6 w-6 text-blue-600" />
                  </div>
                  <h2 className="text-xl font-semibold mb-2">Quick Start Guide</h2>
                  <p className="text-gray-600 mb-4">Get up and running with Nayamax in less than 5 minutes</p>
                  <a href="#" className="text-blue-600 hover:text-blue-700 font-medium inline-flex items-center">
                    Learn more <ChevronRight className="h-4 w-4 ml-1" />
                  </a>
                </div>
                
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                  <div className="p-3 bg-blue-50 rounded-lg w-fit mb-4">
                    <Code className="h-6 w-6 text-blue-600" />
                  </div>
                  <h2 className="text-xl font-semibold mb-2">API Reference</h2>
                  <p className="text-gray-600 mb-4">Complete API documentation with examples</p>
                  <a href="#" className="text-blue-600 hover:text-blue-700 font-medium inline-flex items-center">
                    Explore API <ChevronRight className="h-4 w-4 ml-1" />
                  </a>
                </div>
              </div>

              <section id="getting-started" className="mb-12">
                <h2 className="text-3xl font-bold mb-6">Getting Started</h2>
                <p className="text-gray-600 mb-6">
                  Welcome to Nayamax documentation! Here you'll find everything you need to know about integrating and using our e-commerce platform.
                </p>
                
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-6">
                  <h3 className="text-xl font-semibold mb-4">Prerequisites</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <div className="p-1 bg-green-50 rounded-full mr-3 mt-1">
                        <Shield className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <strong className="block text-gray-900">Create an account</strong>
                        <span className="text-gray-600">Sign up for a Nayamax account to get your API keys</span>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="p-1 bg-green-50 rounded-full mr-3 mt-1">
                        <Database className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <strong className="block text-gray-900">Set up your store</strong>
                        <span className="text-gray-600">Configure your store settings and add your first products</span>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="p-1 bg-green-50 rounded-full mr-3 mt-1">
                        <Book className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <strong className="block text-gray-900">Read the guides</strong>
                        <span className="text-gray-600">Familiarize yourself with our platform features and capabilities</span>
                      </div>
                    </li>
                  </ul>
                </div>

                <div className="bg-blue-50 border border-blue-100 rounded-xl p-6">
                  <h3 className="text-xl font-semibold mb-4">Need help?</h3>
                  <p className="text-gray-600 mb-4">
                    Our support team is available 24/7 to help you with any questions or issues you might have.
                  </p>
                  <div className="flex space-x-4">
                    <a href="#" className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors">
                      Contact Support
                    </a>
                    <a href="#" className="bg-white text-blue-600 px-4 py-2 rounded-lg font-medium hover:bg-blue-50 transition-colors">
                      Join Community
                    </a>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}