import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, MessageSquare, Send, Clock } from 'lucide-react';
import { Navbar } from '../components/Navbar';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement form submission
    console.log('Form submitted:', formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar transparent />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-nayamax-blue to-blue-800 py-24">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center pt-20">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Get in Touch
            </h1>
            <p className="text-xl text-blue-100">
              Have questions? We're here to help and would love to hear from you
            </p>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-3 gap-8 mb-16">
            <ContactCard 
              icon={<Phone className="h-6 w-6" />}
              title="Phone"
              info="+226 76 54 32 10"
              subInfo="Mon-Fri from 8am to 5pm"
            />
            <ContactCard 
              icon={<Mail className="h-6 w-6" />}
              title="Email"
              info="support@nayamax.com"
              subInfo="We'll respond within 24 hours"
            />
            <ContactCard 
              icon={<MapPin className="h-6 w-6" />}
              title="Office"
              info="123 Innovation Hub"
              subInfo="Ouagadougou, Burkina Faso"
            />
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-nayamax-blue focus:border-nayamax-blue transition-colors"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-nayamax-blue focus:border-nayamax-blue transition-colors"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-nayamax-blue focus:border-nayamax-blue transition-colors"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={6}
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-nayamax-blue focus:border-nayamax-blue transition-colors"
                    required
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-nayamax-blue text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors flex items-center justify-center"
                >
                  <Send className="h-5 w-5 mr-2" />
                  Send Message
                </button>
              </form>
            </div>

            {/* FAQ Section */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
              <div className="space-y-4">
                <FaqCard 
                  question="How quickly can I get started?"
                  answer="You can start setting up your store immediately after signing up. The process typically takes less than 5 minutes."
                />
                <FaqCard 
                  question="What payment methods do you support?"
                  answer="We support various payment methods including Mobile Money, bank transfers, and major credit cards."
                />
                <FaqCard 
                  question="Do you offer technical support?"
                  answer="Yes, we provide 24/7 technical support through email, phone, and live chat for all our customers."
                />
                <FaqCard 
                  question="Can I try before I buy?"
                  answer="Yes! We offer a 14-day free trial with full access to all features. No credit card required."
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Support Hours */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              <div className="text-white">
                <h2 className="text-2xl font-bold mb-4">Support Hours</h2>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <Clock className="h-6 w-6 mr-3 text-yellow-400" />
                    <div>
                      <h3 className="font-semibold mb-1">Monday - Friday</h3>
                      <p className="text-gray-300">8:00 AM - 5:00 PM WAT</p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <MessageSquare className="h-6 w-6 mr-3 text-yellow-400" />
                    <div>
                      <h3 className="font-semibold mb-1">24/7 Email Support</h3>
                      <p className="text-gray-300">Always here to help</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-white">
                <h2 className="text-2xl font-bold mb-4">Emergency Support</h2>
                <p className="text-gray-300 mb-4">
                  For urgent issues outside business hours, please use our emergency support line:
                </p>
                <div className="bg-white/10 p-4 rounded-lg">
                  <p className="text-yellow-400 font-semibold">+226 76 54 32 11</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function ContactCard({ icon, title, info, subInfo }) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
      <div className="p-3 bg-blue-50 rounded-lg w-fit mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-900 font-medium mb-1">{info}</p>
      <p className="text-gray-600">{subInfo}</p>
    </div>
  );
}

function FaqCard({ question, answer }) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="text-lg font-semibold mb-2">{question}</h3>
      <p className="text-gray-600">{answer}</p>
    </div>
  );
}