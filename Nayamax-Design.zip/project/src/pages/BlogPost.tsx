import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock, User, Tag } from 'lucide-react';
import { Navbar } from '../components/Navbar';

export function BlogPost() {
  const { slug } = useParams();
  
  // In a real app, this would fetch from an API
  const post = getBlogPost(slug);

  if (!post) {
    return <div>Post not found</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-6">
          <Link to="/blog" className="inline-flex items-center text-gray-600 hover:text-nayamax-blue mb-8">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Blog
          </Link>

          <article className="max-w-4xl mx-auto">
            {/* Hero Image */}
            <div className="rounded-2xl overflow-hidden mb-8 aspect-video">
              <img
                src={post.image}
                alt={post.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Meta Information */}
            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mb-6">
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-2" />
                {post.date}
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2" />
                {post.readTime} read
              </div>
              <div className="flex items-center">
                <User className="h-4 w-4 mr-2" />
                By {post.author}
              </div>
            </div>

            {/* Title */}
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              {post.title}
            </h1>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-8">
              {post.tags.map((tag) => (
                <Link
                  key={tag}
                  to={`/blog/tag/${tag}`}
                  className="inline-flex items-center px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-sm hover:bg-blue-100"
                >
                  <Tag className="h-3 w-3 mr-1" />
                  {tag}
                </Link>
              ))}
            </div>

            {/* Content */}
            <div className="prose prose-lg max-w-none">
              {post.content.map((section, index) => (
                <section key={index} className="mb-8">
                  {section.type === 'paragraph' && (
                    <p className="text-gray-600 leading-relaxed">{section.content}</p>
                  )}
                  {section.type === 'heading' && (
                    <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">{section.content}</h2>
                  )}
                  {section.type === 'image' && (
                    <figure className="my-8">
                      <img
                        src={section.url}
                        alt={section.caption}
                        className="rounded-xl w-full"
                      />
                      <figcaption className="text-center text-sm text-gray-500 mt-2">
                        {section.caption}
                      </figcaption>
                    </figure>
                  )}
                </section>
              ))}
            </div>

            {/* Author Bio */}
            <div className="mt-12 p-8 bg-white rounded-xl shadow-sm">
              <div className="flex items-start space-x-4">
                <img
                  src={post.authorImage}
                  alt={post.author}
                  className="w-16 h-16 rounded-full"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">{post.author}</h3>
                  <p className="text-gray-500 text-sm">{post.authorRole}</p>
                  <p className="text-gray-600 mt-2">{post.authorBio}</p>
                </div>
              </div>
            </div>
          </article>
        </div>
      </main>
    </div>
  );
}

// Mock data function - in a real app, this would fetch from an API
function getBlogPost(slug: string | undefined) {
  const posts = {
    'future-of-ecommerce': {
      title: 'The Future of E-commerce in Africa: Trends to Watch in 2024',
      date: 'March 15, 2024',
      readTime: '5 min',
      author: 'Aminata Diallo',
      authorRole: 'CEO, Nayamax',
      authorImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      authorBio: 'Aminata is the founder and CEO of Nayamax, with over 10 years of experience in African e-commerce.',
      image: 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=2000&q=80',
      tags: ['ecommerce', 'africa', 'trends', 'technology'],
      content: [
        {
          type: 'paragraph',
          content: 'The African e-commerce landscape is undergoing a remarkable transformation, driven by technological advancements, changing consumer behaviors, and innovative solutions to unique regional challenges.'
        },
        {
          type: 'heading',
          content: 'Mobile Commerce Takes Center Stage'
        },
        {
          type: 'paragraph',
          content: 'With smartphone penetration continuing to rise across the continent, mobile commerce is becoming the primary way Africans shop online. This trend is particularly pronounced in countries like Kenya, Nigeria, and South Africa, where mobile payment solutions are already deeply integrated into daily life.'
        },
        {
          type: 'image',
          url: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=1200&q=80',
          caption: 'Mobile payments are revolutionizing African commerce'
        },
        {
          type: 'heading',
          content: 'Local Payment Solutions'
        },
        {
          type: 'paragraph',
          content: 'The integration of local payment methods, particularly mobile money services, continues to be a crucial factor in the growth of e-commerce. Solutions that bridge the gap between traditional and digital payment methods are seeing rapid adoption.'
        }
      ]
    },
    'start-online-store': {
      title: 'How to Start Your Online Store in 5 Simple Steps',
      date: 'March 12, 2024',
      readTime: '8 min',
      author: 'Ibrahim Kone',
      authorRole: 'Head of Product, Nayamax',
      authorImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
      authorBio: 'Ibrahim leads product development at Nayamax, focusing on making e-commerce accessible to all African businesses.',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
      tags: ['guide', 'startup', 'business'],
      content: [
        {
          type: 'paragraph',
          content: 'Starting an online store has never been easier. With the right platform and approach, you can have your business up and running in no time.'
        }
      ]
    }
  };

  return slug ? posts[slug as keyof typeof posts] : null;
}