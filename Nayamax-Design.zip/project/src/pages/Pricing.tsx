import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Plus, X, Shield, CreditCard, Zap, Menu } from 'lucide-react';

export function Pricing() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-lg' : 'bg-transparent'}`}>
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <img src="/nayamax-logo.png" alt="Nayamax" className="h-10" />
            </Link>
            
            <div className="hidden md:flex space-x-8">
              <Link to="/#features" className={`hover:text-blue-600 transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>Features</Link>
              <Link to="/#how-it-works" className={`hover:text-blue-600 transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>How It Works</Link>
              <Link to="/#testimonials" className={`hover:text-blue-600 transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>Success Stories</Link>
              <Link to="/pricing" className={`hover:text-blue-600 transition-colors ${isScrolled ? 'text-gray-700' : 'text-white'}`}>Pricing</Link>
            </div>
            
            <div className="hidden md:flex space-x-4">
              <Link to="/login" className={`px-6 py-2 rounded-full font-semibold transition-colors ${isScrolled ? 'text-gray-700 hover:text-blue-600' : 'text-white hover:text-blue-200'}`}>
                Login
              </Link>
              <Link to="/signup" className="bg-yellow-400 text-blue-900 px-6 py-2 rounded-full font-semibold hover:bg-yellow-300 transition-colors">
                Start Free
              </Link>
            </div>

            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? 
                <X className={isScrolled ? 'text-gray-900' : 'text-white'} /> : 
                <Menu className={isScrolled ? 'text-gray-900' : 'text-white'} />
              }
            </button>
          </div>

          {isMenuOpen && (
            <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-lg py-4">
              <div className="flex flex-col space-y-4 px-6">
                <Link to="/#features" className="text-gray-700 hover:text-blue-600">Features</Link>
                <Link to="/#how-it-works" className="text-gray-700 hover:text-blue-600">How It Works</Link>
                <Link to="/#testimonials" className="text-gray-700 hover:text-blue-600">Success Stories</Link>
                <Link to="/pricing" className="text-gray-700 hover:text-blue-600">Pricing</Link>
                <hr className="border-gray-200" />
                <Link to="/login" className="text-gray-700 hover:text-blue-600 text-left">Login</Link>
                <Link to="/signup" className="bg-yellow-400 text-blue-900 px-6 py-2 rounded-full font-semibold hover:bg-yellow-300 transition-colors text-center">
                  Start Free
                </Link>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-800 py-20 pt-32">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Simple, Transparent Pricing for Everyone
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Start free and scale as your business grows. No hidden fees, no surprises.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/signup" className="bg-yellow-400 text-blue-900 px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors">
                Start Free Trial
              </Link>
              <button className="bg-white/10 text-white px-8 py-4 rounded-full font-semibold hover:bg-white/20 transition-colors">
                Compare Plans
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8 mb-20">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No Hidden Fees</h3>
              <p className="text-gray-600">Transparent pricing with no surprise charges or hidden costs</p>
            </div>
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CreditCard className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Flexible Payments</h3>
              <p className="text-gray-600">Choose from multiple payment methods including Mobile Money</p>
            </div>
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Instant Setup</h3>
              <p className="text-gray-600">Get started immediately with our 14-day free trial</p>
            </div>
          </div>

          {/* Pricing Tables */}
          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Starter Plan */}
            <div className="relative bg-white rounded-2xl shadow-lg overflow-hidden transform hover:-translate-y-1 transition-all duration-300 border border-gray-100">
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Starter</h3>
                <p className="text-gray-600 mb-6">Perfect for new businesses</p>
                <div className="flex items-baseline mb-8">
                  <span className="text-4xl font-bold text-gray-900">Free</span>
                  <span className="text-gray-600 ml-2">/month</span>
                </div>
                <ul className="space-y-4 mb-8">
                  <PricingFeature text="Up to 50 products" />
                  <PricingFeature text="Basic analytics" />
                  <PricingFeature text="Mobile money payments" />
                  <PricingFeature text="24/7 support" />
                  <PricingFeature text="Single store" />
                  <PricingFeature text="Basic templates" />
                </ul>
                <Link to="/signup" className="w-full bg-gray-100 text-gray-900 px-6 py-3 rounded-full font-semibold hover:bg-gray-200 transition-colors block text-center">
                  Start Free Trial
                </Link>
              </div>
            </div>

            {/* Growth Plan */}
            <div className="relative bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl shadow-xl overflow-hidden transform hover:-translate-y-1 transition-all duration-300">
              <div className="absolute top-0 right-0 mt-4 mr-4">
                <div className="bg-yellow-400 text-blue-900 text-xs font-bold px-3 py-1 rounded-full">
                  MOST POPULAR
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-bold text-white mb-2">Growth</h3>
                <p className="text-blue-100 mb-6">For growing businesses</p>
                <div className="flex items-baseline mb-8">
                  <span className="text-4xl font-bold text-white">25,000</span>
                  <span className="text-blue-100 ml-2">FCFA/month</span>
                </div>
                <ul className="space-y-4 mb-8">
                  <PricingFeature text="Unlimited products" light />
                  <PricingFeature text="Advanced analytics" light />
                  <PricingFeature text="All payment methods" light />
                  <PricingFeature text="Priority support" light />
                  <PricingFeature text="Custom domain" light />
                  <PricingFeature text="Marketing tools" light />
                  <PricingFeature text="Premium templates" light />
                  <PricingFeature text="API access" light />
                </ul>
                <Link to="/signup" className="w-full bg-yellow-400 text-blue-900 px-6 py-3 rounded-full font-semibold hover:bg-yellow-300 transition-colors block text-center">
                  Get Started
                </Link>
              </div>
            </div>

            {/* Enterprise Plan */}
            <div className="relative bg-white rounded-2xl shadow-lg overflow-hidden transform hover:-translate-y-1 transition-all duration-300 border border-gray-100">
              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Enterprise</h3>
                <p className="text-gray-600 mb-6">For large businesses</p>
                <div className="flex items-baseline mb-8">
                  <span className="text-4xl font-bold text-gray-900">75,000</span>
                  <span className="text-gray-600 ml-2">FCFA/month</span>
                </div>
                <ul className="space-y-4 mb-8">
                  <PricingFeature text="Everything in Growth" />
                  <PricingFeature text="Multiple stores" />
                  <PricingFeature text="Advanced reporting" />
                  <PricingFeature text="API access" />
                  <PricingFeature text="Dedicated support" />
                  <PricingFeature text="Custom integrations" />
                  <PricingFeature text="White-label solution" />
                  <PricingFeature text="Custom development" />
                </ul>
                <button className="w-full bg-gray-900 text-white px-6 py-3 rounded-full font-semibold hover:bg-gray-800 transition-colors">
                  Contact Sales
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Comparison */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">Compare Plans in Detail</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 px-6">Features</th>
                  <th className="text-center py-4 px-6">Starter</th>
                  <th className="text-center py-4 px-6">Growth</th>
                  <th className="text-center py-4 px-6">Enterprise</th>
                </tr>
              </thead>
              <tbody>
                <ComparisonRow 
                  feature="Products"
                  starter="Up to 50"
                  growth="Unlimited"
                  enterprise="Unlimited"
                />
                <ComparisonRow 
                  feature="Analytics"
                  starter="Basic"
                  growth="Advanced"
                  enterprise="Custom"
                />
                <ComparisonRow 
                  feature="Support"
                  starter="Email"
                  growth="Priority"
                  enterprise="Dedicated"
                />
                <ComparisonRow 
                  feature="Templates"
                  starter="Basic"
                  growth="Premium"
                  enterprise="Custom"
                />
                <ComparisonRow 
                  feature="API Access"
                  starter="No"
                  growth="Yes"
                  enterprise="Advanced"
                />
                <ComparisonRow 
                  feature="Custom Domain"
                  starter="No"
                  growth="Yes"
                  enterprise="Yes"
                />
                <ComparisonRow 
                  feature="Marketing Tools"
                  starter="Basic"
                  growth="Advanced"
                  enterprise="Enterprise"
                />
                <ComparisonRow 
                  feature="Payment Methods"
                  starter="Mobile Money"
                  growth="All Methods"
                  enterprise="Custom"
                />
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <FaqItem 
              question="How does the 14-day trial work?"
              answer="Start with our Growth plan features for 14 days, completely free. No credit card required. If you don't upgrade, you'll automatically switch to the free Starter plan."
            />
            <FaqItem 
              question="Can I change plans later?"
              answer="Yes! You can upgrade, downgrade, or cancel your plan at any time. Changes take effect at the start of your next billing cycle."
            />
            <FaqItem 
              question="What payment methods do you accept?"
              answer="We accept Mobile Money (Orange Money, MTN Mobile Money), bank transfers, and major credit cards for all paid plans."
            />
            <FaqItem 
              question="Is there a contract or commitment?"
              answer="No long-term contracts. All plans are month-to-month, and you can cancel anytime without penalty."
            />
            <FaqItem 
              question="Do you offer refunds?"
              answer="Yes, we offer a 30-day money-back guarantee if you're not satisfied with our service."
            />
            <FaqItem 
              question="What kind of support do you provide?"
              answer="All plans include 24/7 support. Growth plans get priority support, while Enterprise plans get dedicated support with custom SLAs."
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-900 py-20">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to Start Your Success Story?
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Join thousands of successful African entrepreneurs who are growing their businesses with Nayamax
            </p>
            <Link to="/signup" className="bg-yellow-400 text-blue-900 px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors inline-block">
              Start Your Free Trial
            </Link>
            <p className="mt-4 text-blue-200">No credit card required • 14-day free trial</p>
          </div>
        </div>
      </section>
    </div>
  );
}

function PricingFeature({ text, light = false }) {
  return (
    <li className="flex items-center">
      <CheckCircle2 className={`h-5 w-5 ${light ? 'text-yellow-400' : 'text-green-500'} mr-2`} />
      <span className={light ? 'text-blue-100' : 'text-gray-700'}>{text}</span>
    </li>
  );
}

function FaqItem({ question, answer }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-gray-200 pb-4">
      <button
        className="flex justify-between items-center w-full text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-lg font-semibold text-gray-900">{question}</span>
        {isOpen ? (
          <X className="h-5 w-5 text-gray-500" />
        ) : (
          <Plus className="h-5 w-5 text-gray-500" />
        )}
      </button>
      {isOpen && (
        <p className="mt-2 text-gray-600">{answer}</p>
      )}
    </div>
  );
}

function ComparisonRow({ feature, starter, growth, enterprise }) {
  return (
    <tr className="border-b border-gray-200">
      <td className="py-4 px-6 font-medium">{feature}</td>
      <td className="text-center py-4 px-6">{starter}</td>
      <td className="text-center py-4 px-6 font-medium text-blue-600">{growth}</td>
      <td className="text-center py-4 px-6">{enterprise}</td>
    </tr>
  );
}