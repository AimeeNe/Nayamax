import React from 'react';
import { Link } from 'react-router-dom';
import { Users, Globe2, Target, Award, ArrowRight } from 'lucide-react';
import { Navbar } from '../components/Navbar';

export function About() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar transparent />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-nayamax-blue to-blue-800 py-24">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?auto=format&fit=crop&w=2000&q=80')] opacity-10 bg-cover bg-center" />
        <div className="container mx-auto px-6 relative pt-20">
          <div className="flex flex-col items-center text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Empowering African Commerce
            </h1>
            <p className="text-xl text-blue-100 max-w-2xl mb-8">
              We're on a mission to revolutionize e-commerce in Africa by providing accessible, powerful tools for businesses of all sizes.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors inline-flex items-center">
                Join Our Mission <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=800&q=80" 
                alt="Team working" 
                className="rounded-2xl shadow-2xl"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Vision</h2>
              <p className="text-gray-600 mb-8 text-lg leading-relaxed">
                At Nayamax, we envision a future where every African business, regardless of size, has access to powerful e-commerce tools that enable them to reach customers globally and compete effectively in the digital marketplace.
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="p-2 bg-blue-50 rounded-lg mr-4">
                    <Target className="h-6 w-6 text-nayamax-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Mission-Driven</h3>
                    <p className="text-gray-600">Dedicated to empowering African businesses through technology</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="p-2 bg-blue-50 rounded-lg mr-4">
                    <Globe2 className="h-6 w-6 text-nayamax-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Local Focus, Global Reach</h3>
                    <p className="text-gray-600">Building solutions tailored for Africa with global standards</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
            <p className="text-xl text-gray-600">
              A diverse group of passionate individuals working together to transform African e-commerce
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <TeamMember 
              name="Aminata Diallo"
              role="Founder & CEO"
              image="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80"
              bio="Former Google engineer with 10+ years experience in African tech"
            />
            <TeamMember 
              name="Ibrahim Kone"
              role="Chief Technology Officer"
              image="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80"
              bio="Tech veteran with expertise in building scalable platforms"
            />
            <TeamMember 
              name="Sarah Mensah"
              role="Head of Operations"
              image="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=400&q=80"
              bio="Operations expert with experience across multiple African markets"
            />
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold mb-4">Our Values</h2>
            <p className="text-xl text-gray-600">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <ValueCard 
              icon={<Users className="h-8 w-8 text-nayamax-blue" />}
              title="Customer First"
              description="Everything we do starts with our customers' needs"
            />
            <ValueCard 
              icon={<Award className="h-8 w-8 text-nayamax-blue" />}
              title="Excellence"
              description="We strive for excellence in every aspect of our work"
            />
            <ValueCard 
              icon={<Globe2 className="h-8 w-8 text-nayamax-blue" />}
              title="Local Impact"
              description="Making a positive impact in African communities"
            />
            <ValueCard 
              icon={<Target className="h-8 w-8 text-nayamax-blue" />}
              title="Innovation"
              description="Constantly innovating to solve unique challenges"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-nayamax-blue py-20">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Join Us in Transforming African Commerce
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Be part of the revolution in African e-commerce
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors">
                Get Started Today
              </Link>
              <Link to="/contact" className="bg-white/10 text-white px-8 py-4 rounded-full font-semibold hover:bg-white/20 transition-colors">
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function TeamMember({ name, role, image, bio }) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
      <img 
        src={image} 
        alt={name} 
        className="w-32 h-32 rounded-full mx-auto mb-6 object-cover"
      />
      <div className="text-center">
        <h3 className="text-xl font-semibold mb-1">{name}</h3>
        <p className="text-nayamax-blue font-medium mb-2">{role}</p>
        <p className="text-gray-600">{bio}</p>
      </div>
    </div>
  );
}

function ValueCard({ icon, title, description }) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
      <div className="p-3 bg-blue-50 rounded-lg w-fit mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}