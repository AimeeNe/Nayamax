import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, User, ChevronRight, Search, Tag } from 'lucide-react';
import { Navbar } from '../components/Navbar';

export function Blog() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-nayamax-blue to-blue-800 py-24">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center pt-20">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Nayamax Blog
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Insights, tips, and news about e-commerce in Africa
            </p>
            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="search"
                placeholder="Search articles..."
                className="w-full pl-12 pr-4 py-3 rounded-full border-2 border-white/20 bg-white/10 text-white placeholder-blue-100 focus:outline-none focus:border-white"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Featured Post */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="grid md:grid-cols-2">
              <div className="relative h-64 md:h-auto">
                <img
                  src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=1200&q=80"
                  alt="Featured post"
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </div>
              <div className="p-8 md:p-12">
                <div className="flex items-center text-sm text-gray-500 mb-4">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>March 15, 2024</span>
                  <span className="mx-2">•</span>
                  <Clock className="h-4 w-4 mr-2" />
                  <span>5 min read</span>
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  The Future of E-commerce in Africa: Trends to Watch in 2024
                </h2>
                <p className="text-gray-600 mb-6">
                  Discover the key trends shaping the future of online retail in Africa, from mobile commerce to innovative payment solutions.
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img
                      src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=64&h=64"
                      alt="Author"
                      className="w-10 h-10 rounded-full mr-3"
                    />
                    <div>
                      <p className="font-medium text-gray-900">Aminata Diallo</p>
                      <p className="text-sm text-gray-500">CEO, Nayamax</p>
                    </div>
                  </div>
                  <Link
                    to="/blog/future-of-ecommerce"
                    className="inline-flex items-center text-nayamax-blue font-semibold hover:text-blue-700"
                  >
                    Read More <ChevronRight className="h-4 w-4 ml-1" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Latest Posts */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Latest Articles</h2>
              <div className="space-y-8">
                <BlogPost
                  title="How to Start Your Online Store in 5 Simple Steps"
                  excerpt="A step-by-step guide to launching your e-commerce business with Nayamax"
                  image="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80"
                  author="Ibrahim Kone"
                  date="March 12, 2024"
                  readTime="8 min"
                  slug="start-online-store"
                />
                <BlogPost
                  title="Mobile Money Integration: A Complete Guide"
                  excerpt="Learn how to integrate mobile payment solutions into your online store"
                  image="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=800&q=80"
                  author="Sarah Mensah"
                  date="March 10, 2024"
                  readTime="6 min"
                  slug="mobile-money-guide"
                />
                <BlogPost
                  title="Marketing Strategies for African E-commerce"
                  excerpt="Effective marketing tactics to grow your online business in Africa"
                  image="https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?auto=format&fit=crop&w=800&q=80"
                  author="Jean Koné"
                  date="March 8, 2024"
                  readTime="7 min"
                  slug="marketing-strategies"
                />
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              {/* Categories */}
              <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Categories</h3>
                <div className="space-y-2">
                  <CategoryLink name="E-commerce Tips" count={12} />
                  <CategoryLink name="Success Stories" count={8} />
                  <CategoryLink name="Technology" count={15} />
                  <CategoryLink name="Marketing" count={10} />
                  <CategoryLink name="Business Growth" count={7} />
                </div>
              </div>

              {/* Popular Tags */}
              <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Popular Tags</h3>
                <div className="flex flex-wrap gap-2">
                  <TagButton name="ecommerce" />
                  <TagButton name="africa" />
                  <TagButton name="business" />
                  <TagButton name="mobile" />
                  <TagButton name="payments" />
                  <TagButton name="marketing" />
                  <TagButton name="startup" />
                  <TagButton name="technology" />
                </div>
              </div>

              {/* Newsletter */}
              <div className="bg-nayamax-blue rounded-xl shadow-lg p-6">
                <h3 className="text-lg font-bold text-white mb-2">Subscribe to Our Newsletter</h3>
                <p className="text-blue-100 mb-4">Get the latest articles and business tips right in your inbox.</p>
                <form className="space-y-3">
                  <input
                    type="email"
                    placeholder="Your email address"
                    className="w-full px-4 py-2 rounded-lg border border-white/20 bg-white/10 text-white placeholder-blue-100 focus:outline-none focus:border-white"
                  />
                  <button
                    type="submit"
                    className="w-full bg-yellow-400 text-nayamax-blue px-4 py-2 rounded-lg font-semibold hover:bg-yellow-300 transition-colors"
                  >
                    Subscribe
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function BlogPost({ title, excerpt, image, author, date, readTime, slug }) {
  return (
    <article className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
      <Link to={`/blog/${slug}`} className="block">
        <div className="relative h-48">
          <img
            src={image}
            alt={title}
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>
        <div className="p-6">
          <div className="flex items-center text-sm text-gray-500 mb-4">
            <Calendar className="h-4 w-4 mr-2" />
            <span>{date}</span>
            <span className="mx-2">•</span>
            <Clock className="h-4 w-4 mr-2" />
            <span>{readTime} read</span>
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
          <p className="text-gray-600 mb-4">{excerpt}</p>
          <div className="flex items-center">
            <User className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm text-gray-500">By {author}</span>
          </div>
        </div>
      </Link>
    </article>
  );
}

function CategoryLink({ name, count }) {
  return (
    <Link to={`/blog/category/${name.toLowerCase()}`} className="flex items-center justify-between py-2 text-gray-600 hover:text-nayamax-blue">
      <span>{name}</span>
      <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">{count}</span>
    </Link>
  );
}

function TagButton({ name }) {
  return (
    <Link
      to={`/blog/tag/${name}`}
      className="inline-flex items-center px-3 py-1 rounded-full bg-gray-100 text-gray-600 text-sm hover:bg-gray-200"
    >
      <Tag className="h-3 w-3 mr-1" />
      {name}
    </Link>
  );
}