import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Users, Globe2, BarChart as ChartBar, Rocket, Shield, DollarSign, BarChart3 } from 'lucide-react';
import { Navbar } from '../components/Navbar';

export function Investors() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-nayamax-blue to-blue-800 py-24">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=2000&q=80')] opacity-10 bg-cover bg-center" />
        <div className="container mx-auto px-6 relative pt-20">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Invest in the Future of African Commerce
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Join us in revolutionizing e-commerce across Africa through innovative technology and local solutions
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a href="#contact" className="bg-yellow-400 text-nayamax-blue px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors">
                Connect with Us
              </a>
              <a href="#metrics" className="bg-white/10 text-white px-8 py-4 rounded-full font-semibold hover:bg-white/20 transition-colors">
                View Metrics
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Key Metrics */}
      <section id="metrics" className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <MetricCard
              icon={<Users className="h-8 w-8 text-blue-600" />}
              number="2,000+"
              label="Active Merchants"
              growth="+45% YoY"
            />
            <MetricCard
              icon={<Globe2 className="h-8 w-8 text-blue-600" />}
              number="10+"
              label="African Countries"
              growth="Expanding"
            />
            <MetricCard
              icon={<ChartBar className="h-8 w-8 text-blue-600" />}
              number="$15M+"
              label="GMV"
              growth="+120% YoY"
            />
            <MetricCard
              icon={<TrendingUp className="h-8 w-8 text-blue-600" />}
              number="85%"
              label="Revenue Growth"
              growth="Year-over-Year"
            />
          </div>
        </div>
      </section>

      {/* Investment Thesis */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Why Invest in Nayamax?</h2>
            <p className="text-xl text-gray-600">
              We're building the infrastructure for the next generation of African commerce
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <ThesisCard
              icon={<Rocket className="h-8 w-8 text-blue-600" />}
              title="Market Opportunity"
              description="Tap into Africa's rapidly growing e-commerce market, projected to reach $75 billion by 2025"
            />
            <ThesisCard
              icon={<Shield className="h-8 w-8 text-blue-600" />}
              title="Proven Technology"
              description="Built by a team with deep expertise in African markets and scalable technology"
            />
            <ThesisCard
              icon={<DollarSign className="h-8 w-8 text-blue-600" />}
              title="Strong Unit Economics"
              description="Sustainable business model with high merchant retention and expanding margins"
            />
          </div>
        </div>
      </section>

      {/* Growth Trajectory */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Growth Trajectory</h2>
              <div className="space-y-6">
                <MilestoneCard
                  year="2023"
                  title="Market Expansion"
                  description="Launched in 5 new countries with 200% merchant growth"
                />
                <MilestoneCard
                  year="2024"
                  title="Product Innovation"
                  description="Introduced AI-powered analytics and mobile money integration"
                />
                <MilestoneCard
                  year="2025"
                  title="Scale Operations"
                  description="Targeting presence in 15+ countries with $100M+ GMV"
                />
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=800&q=80"
                alt="Growth Chart"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-16">Leadership Team</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <TeamMember
              name="Aminata Diallo"
              role="Founder & CEO"
              image="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80"
              bio="Former Google engineer with 10+ years experience in African tech"
            />
            <TeamMember
              name="Ibrahim Kone"
              role="Chief Technology Officer"
              image="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80"
              bio="Tech veteran with expertise in building scalable platforms"
            />
            <TeamMember
              name="Sarah Mensah"
              role="Chief Financial Officer"
              image="https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=400&q=80"
              bio="Former investment banker with focus on emerging markets"
            />
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-nayamax-blue">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Connect with Our Investment Team
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Learn more about investment opportunities at Nayamax
            </p>
            <form className="bg-white p-8 rounded-xl shadow-lg">
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-1">
                    Company
                  </label>
                  <input
                    type="text"
                    id="company"
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="investment" className="block text-sm font-medium text-gray-700 mb-1">
                    Investment Range
                  </label>
                  <select
                    id="investment"
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    required
                  >
                    <option value="">Select range</option>
                    <option value="100k-500k">$100K - $500K</option>
                    <option value="500k-1m">$500K - $1M</option>
                    <option value="1m-5m">$1M - $5M</option>
                    <option value="5m+">$5M+</option>
                  </select>
                </div>
              </div>
              <div className="mb-6">
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                  Message
                </label>
                <textarea
                  id="message"
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-nayamax-blue text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Submit Inquiry
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}

function MetricCard({ icon, number, label, growth }) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
      <div className="p-3 bg-blue-50 rounded-lg w-fit mb-4">
        {icon}
      </div>
      <div className="text-2xl font-bold text-gray-900">{number}</div>
      <div className="text-gray-600">{label}</div>
      <div className="text-green-500 text-sm font-medium mt-2">{growth}</div>
    </div>
  );
}

function ThesisCard({ icon, title, description }) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border border-gray-100">
      <div className="p-3 bg-blue-50 rounded-lg w-fit mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function MilestoneCard({ year, title, description }) {
  return (
    <div className="flex items-start space-x-4">
      <div className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full font-semibold">
        {year}
      </div>
      <div>
        <h3 className="font-semibold text-gray-900">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
}

function TeamMember({ name, role, image, bio }) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
      <img 
        src={image} 
        alt={name} 
        className="w-32 h-32 rounded-full mx-auto mb-6 object-cover"
      />
      <div className="text-center">
        <h3 className="text-xl font-semibold mb-1">{name}</h3>
        <p className="text-blue-600 font-medium mb-2">{role}</p>
        <p className="text-gray-600">{bio}</p>
      </div>
    </div>
  );
}