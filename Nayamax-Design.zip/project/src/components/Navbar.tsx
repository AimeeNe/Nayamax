import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  transparent?: boolean;
}

export function Navbar({ transparent = false }: NavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const shouldBeTransparent = transparent && !isScrolled;

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${shouldBeTransparent ? 'bg-transparent' : 'bg-white shadow-lg'}`}>
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <img src="/nayamax-logo.png" alt="Nayamax" className="h-10" />
          </Link>
          
          <div className="hidden md:flex space-x-8">
            <Link to="/#features" className={`hover:text-nayamax-blue transition-colors ${shouldBeTransparent ? 'text-white' : 'text-gray-700'}`}>Features</Link>
            <Link to="/#how-it-works" className={`hover:text-nayamax-blue transition-colors ${shouldBeTransparent ? 'text-white' : 'text-gray-700'}`}>How It Works</Link>
            <Link to="/about" className={`hover:text-nayamax-blue transition-colors ${shouldBeTransparent ? 'text-white' : 'text-gray-700'}`}>About</Link>
            <Link to="/contact" className={`hover:text-nayamax-blue transition-colors ${shouldBeTransparent ? 'text-white' : 'text-gray-700'}`}>Contact</Link>
            <Link to="/pricing" className={`hover:text-nayamax-blue transition-colors ${shouldBeTransparent ? 'text-white' : 'text-gray-700'}`}>Pricing</Link>
          </div>
          
          <div className="hidden md:flex space-x-4">
            <Link to="/login" className={`px-6 py-2 rounded-full font-semibold transition-colors ${shouldBeTransparent ? 'text-white hover:text-blue-200' : 'text-gray-700 hover:text-nayamax-blue'}`}>
              Login
            </Link>
            <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-6 py-2 rounded-full font-semibold hover:bg-yellow-300 transition-colors">
              Start Free
            </Link>
          </div>

          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? 
              <X className={shouldBeTransparent ? 'text-white' : 'text-gray-900'} /> : 
              <Menu className={shouldBeTransparent ? 'text-white' : 'text-gray-900'} />
            }
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-lg py-4">
            <div className="flex flex-col space-y-4 px-6">
              <Link to="/#features" className="text-gray-700 hover:text-nayamax-blue">Features</Link>
              <Link to="/#how-it-works" className="text-gray-700 hover:text-nayamax-blue">How It Works</Link>
              <Link to="/about" className="text-gray-700 hover:text-nayamax-blue">About</Link>
              <Link to="/contact" className="text-gray-700 hover:text-nayamax-blue">Contact</Link>
              <Link to="/pricing" className="text-gray-700 hover:text-nayamax-blue">Pricing</Link>
              <hr className="border-gray-200" />
              <Link to="/login" className="text-gray-700 hover:text-nayamax-blue text-left">Login</Link>
              <Link to="/signup" className="bg-yellow-400 text-nayamax-blue px-6 py-2 rounded-full font-semibold hover:bg-yellow-300 transition-colors text-center">
                Start Free
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}